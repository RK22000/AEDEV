This project should be initialized with the following folders

`./ref_files/`: containing all the reference files on which to create a prior probabalities

`./orig_exes/`: containing all the original exes to be masked

## Description of dirictories

`active_probs/`: files containg the prior nib probabalities that will be applied on original exes

`masked_dir/`: contains one dirictory for every nibble probabalities file. Each sub dirictory contains a cloaked version of the original exe masked with the corresponding nibble probabality

`orig_exes/`: containing all the original exes to be masked

`ref_files/`: containing all the reference files on which to create a prior probabalities

`ref_probs/`: files containing the prior nib probabalities of reference files 


keep track of the log using `tail cloaklog.txt`

Use this to get count of masked files 130

